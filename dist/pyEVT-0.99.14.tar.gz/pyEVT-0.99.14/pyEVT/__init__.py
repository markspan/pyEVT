from .EvtExchanger import EvtExchanger
EvtExchanger.Initialise()
DeviceSelector=EvtExchanger.Device()
#_evtLister = EvtExchanger().Device()
#_evtLister.S
