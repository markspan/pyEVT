# pyEVT: EventExchanger

wrapper for:

https://github.com/markspan/EventExchanger

## Disclaimer:

C-Sharp code to communicate with the hardware the University of Groningen,
faculty of Behaviour and Social Sciences, department of Research Support developed.

Code Written by Eise Hoekstra and Mark M. Span, Maintained by Mark M. Span

## Usage:

Any environment that can read and use .net code will be able to use this library.

e.g., Matlab and Python.

