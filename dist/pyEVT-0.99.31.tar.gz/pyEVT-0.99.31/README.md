# pyEVT: EventExchanger


## Disclaimer:

Code to communicate with the hardware the University of Groningen,
faculty of Behaviour and Social Sciences, department of Research Support developed.

Code Written by Eise Hoekstra and Mark M. Span, Maintained by Mark M. Span

## Usage:

Rewrite from 0.99.14: pure python implementation using HIDAPI

https://pypi.org/project/hidapi/